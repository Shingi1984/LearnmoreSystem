<!DOCTYPE html>
<html>

   <head>
      <title>HTML Iframes</title>
   </head>
	
   <body>
      <div>
      
      <iframe src = "try/try1.php" width = "920" height = "605">
         Sorry your browser does not support inline frames.
      </iframe>
      </div>
      <div>
      
      <iframe src = "try/try2.php" width = "920" height = "605">
         Sorry your browser does not support inline frames.
      </iframe>
      </div>
       <div>
      
      <iframe src = "try/try3.php" width = "920" height = "605">
         Sorry your browser does not support inline frames.
      </iframe>
      </div><div>
      
      <iframe src = "try/try4.php" width = "920" height = "605">
         Sorry your browser does not support inline frames.
      </iframe>
      </div><div>
      
      <iframe src = "try/try5.php" width = "920" height = "605">
         Sorry your browser does not support inline frames.
      </iframe>
      </div><div>
      
      <iframe src = "try/try6.php" width = "920" height = "605">
         Sorry your browser does not support inline frames.
      </iframe>
      </div><div>
      
      <iframe src = "try/try7.php" width = "920" height = "605">
         Sorry your browser does not support inline frames.
      </iframe>
      </div><div>
      
      <iframe src = "try/try8.php" width = "920" height = "605">
         Sorry your browser does not support inline frames.
      </iframe>
      </div><div>
      
      <iframe src = "try/try9.php" width = "920" height = "605">
         Sorry your browser does not support inline frames.
      </iframe>
      </div><div>
      
      <iframe src = "try/try10.php" width = "920" height = "605">
         Sorry your browser does not support inline frames.
      </iframe>
      </div><div>
      
      <iframe src = "try/try11.php" width = "920" height = "605">
         Sorry your browser does not support inline frames.
      </iframe>
      </div><div>
      
      <iframe src = "try/try12.php" width = "920" height = "605">
         Sorry your browser does not support inline frames.
      </iframe>
      </div>
   </body>
	
</html>